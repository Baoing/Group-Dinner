<template>
  <div class="page">
    <nav-bar title="二维码" />
  </div>
</template>

<script>
 export default {
   data(){
     return {

     }
   },
   created() {

   },
   methods:{

   }
 }
</script>

<style lang="scss" scoped>

</style>