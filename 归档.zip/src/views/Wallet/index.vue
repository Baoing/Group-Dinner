<template>
  <div class="page">
    <nav-bar title="钱包" />
  </div>
</template>

<script>
 export default {
   data(){
     return {

     }
   },
   created() {

   },
   methods:{

   }
 }
</script>

<style lang="scss" scoped>
@import '~@/assets/styles/_variables.scss';

</style>