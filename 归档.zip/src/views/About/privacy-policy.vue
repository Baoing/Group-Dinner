<template>
  <div class="page">
    <nav-bar title="隐私协议"/>
  </div>
</template>

<script>

export default {
  components: {
  },
  data() {
    return {}
  },
  created() {

  },
  methods: {}
}
</script>

<style lang="scss" scoped>
</style>