
// 请求根路径
export const BASEURL = process.env.NODE_ENV === "development" ? "/dev" : "https://newtuancan.beichuanggaoke.com/web/index.php"

// 请求超时
export const TIMEOUT = 5000